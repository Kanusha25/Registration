package com.example.regestration.constants;

public class RegistrationConstants {

	public static final String REGISTER = "register";
}
